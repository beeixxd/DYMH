//
// DYYYFLEXBlockShortcuts.h
//  FLEX
//
//  Created by Tanner on 1/30/20.
//  Copyright © 2020 FLEX Team. All rights reserved.
//

#import "DYYYFLEXShortcutsSection.h"

NS_ASSUME_NONNULL_BEGIN

/// Provides a description of the block's signature
/// and access to an NSMethodSignature of the block
@interface DYYYFLEXBlockShortcuts : DYYYFLEXShortcutsSection

@end

NS_ASSUME_NONNULL_END
