//
//  DYYYFLEXTableView.h
//  FLEX
//
//  由 Tanner 创建于 4/17/19.
//  版权所有 © 2020 FLEX Team. 保留所有权利。
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

#pragma mark 重用标识符

typedef NSString * FLEXTableViewCellReuseIdentifier;

/// 使用 \c UITableViewCellStyleDefault 初始化的常规 \c DYYYFLEXTableViewCell
extern FLEXTableViewCellReuseIdentifier const kFLEXDefaultCell;
/// 使用 \c UITableViewCellStyleSubtitle 初始化的 \c DYYYFLEXSubtitleTableViewCell
extern FLEXTableViewCellReuseIdentifier const kFLEXDetailCell;
/// 使用 \c UITableViewCellStyleDefault 初始化的 \c DYYYFLEXMultilineTableViewCell
extern FLEXTableViewCellReuseIdentifier const kFLEXMultilineCell;
/// 使用 \c UITableViewCellStyleSubtitle 初始化的 \c DYYYFLEXMultilineTableViewCell
extern FLEXTableViewCellReuseIdentifier const kFLEXMultilineDetailCell;
/// 使用 \c UITableViewCellStyleValue1 初始化的 \c DYYYFLEXTableViewCell
extern FLEXTableViewCellReuseIdentifier const kFLEXKeyValueCell;
/// 对两个标签都使用等宽字体的 \c DYYYFLEXSubtitleTableViewCell
extern FLEXTableViewCellReuseIdentifier const kFLEXCodeFontCell;

#pragma mark - DYYYFLEXTableView
@interface DYYYFLEXTableView : UITableView

+ (instancetype)flexDefaultTableView;
+ (instancetype)groupedTableView;
+ (instancetype)plainTableView;
+ (instancetype)style:(UITableViewStyle)style;

/// 对于上面的任何默认重用标识符（标注为 \c FLEXTableViewCellReuseIdentifier 类型），
/// 您不需要注册类，除非您希望为这些重用标识符中的任何一个提供自定义单元格。
/// 默认情况下，分别使用 \c DYYYFLEXTableViewCell，\c DYYYFLEXSubtitleTableViewCell 
/// 和 \c DYYYFLEXMultilineTableViewCell。
///
/// @param registrationMapping 重用标识符到 \c UITableViewCell（子）类对象的映射。
- (void)registerCells:(NSDictionary<NSString *, Class> *)registrationMapping;

@end

NS_ASSUME_NONNULL_END
