//
//  DYYYFLEXMirror.m
//  FLEX
//
//  源自 MirrorKit。
//  Created by Tanner on 6/29/15.
//  Copyright (c) 2020 FLEX Team. All rights reserved.
//

#import "DYYYFLEXMirror.h"
#import "DYYYFLEXProperty.h"
#import "DYYYFLEXMethod.h"
#import "DYYYFLEXIvar.h"
#import "DYYYFLEXProtocol.h"
#import "DYYYFLEXUtility.h"


#pragma mark DYYYFLEXMirror

@implementation DYYYFLEXMirror

- (id)init {
    [NSException
        raise:NSInternalInconsistencyException
        format:@"类实例不应该通过 -init 创建"
    ];
    return nil;
}

#pragma mark 初始化
+ (instancetype)reflect:(id)objectOrClass {
    return [[self alloc] initWithSubject:objectOrClass];
}

- (id)initWithSubject:(id)objectOrClass {
    NSParameterAssert(objectOrClass);
    
    self = [super init];
    if (self) {
        _value = objectOrClass;
        [self examine];
    }
    
    return self;
}

- (NSString *)description {
    return [NSString stringWithFormat:@"<%@ %@=%@>",
        NSStringFromClass(self.class),
        self.isClass ? @"metaclass" : @"class",
        self.className
    ];
}

- (void)examine {
    BOOL isClass = object_isClass(self.value);
    Class cls  = isClass ? self.value : object_getClass(self.value);
    Class meta = object_getClass(cls);
    _className = NSStringFromClass(cls);
    _isClass   = isClass;
    
    unsigned int pcount, cpcount, mcount, cmcount, ivcount, pccount;
    Ivar *objcIvars                       = class_copyIvarList(cls, &ivcount);
    Method *objcMethods                   = class_copyMethodList(cls, &mcount);
    Method *objcClsMethods                = class_copyMethodList(meta, &cmcount);
    objc_property_t *objcProperties       = class_copyPropertyList(cls, &pcount);
    objc_property_t *objcClsProperties    = class_copyPropertyList(meta, &cpcount);
    Protocol *__unsafe_unretained *protos = class_copyProtocolList(cls, &pccount);
    
    _ivars = [NSArray flex_forEachUpTo:ivcount map:^id(NSUInteger i) {
        return [DYYYFLEXIvar ivar:objcIvars[i]];
    }];
    
    _methods = [NSArray flex_forEachUpTo:mcount map:^id(NSUInteger i) {
        return [DYYYFLEXMethod method:objcMethods[i] isInstanceMethod:YES];
    }];
    _classMethods = [NSArray flex_forEachUpTo:cmcount map:^id(NSUInteger i) {
        return [DYYYFLEXMethod method:objcClsMethods[i] isInstanceMethod:NO];
    }];
    
    _properties = [NSArray flex_forEachUpTo:pcount map:^id(NSUInteger i) {
        return [DYYYFLEXProperty property:objcProperties[i] onClass:cls];
    }];
    _classProperties = [NSArray flex_forEachUpTo:cpcount map:^id(NSUInteger i) {
        return [DYYYFLEXProperty property:objcClsProperties[i] onClass:meta];
    }];
    
    _protocols = [NSArray flex_forEachUpTo:pccount map:^id(NSUInteger i) {
        return [DYYYFLEXProtocol protocol:protos[i]];
    }];
    
    // 清理
    free(objcClsProperties);
    free(objcProperties);
    free(objcClsMethods);
    free(objcMethods);
    free(objcIvars);
    free(protos);
    protos = NULL;
}

#pragma mark 其他

- (DYYYFLEXMirror *)superMirror {
    Class cls = _isClass ? _value : object_getClass(_value);
    return [DYYYFLEXMirror reflect:class_getSuperclass(cls)];
}

@end


#pragma mark 扩展镜像

@implementation DYYYFLEXMirror (ExtendedMirror)

- (id)filter:(NSArray *)array forName:(NSString *)name {
    NSPredicate *filter = [NSPredicate predicateWithFormat:@"%K = %@", @"name", name];
    return [array filteredArrayUsingPredicate:filter].firstObject;
}

- (DYYYFLEXMethod *)methodNamed:(NSString *)name {
    return [self filter:self.methods forName:name];
}

- (DYYYFLEXMethod *)classMethodNamed:(NSString *)name {
    return [self filter:self.classMethods forName:name];
}

- (DYYYFLEXProperty *)propertyNamed:(NSString *)name {
    return [self filter:self.properties forName:name];
}

- (DYYYFLEXProperty *)classPropertyNamed:(NSString *)name {
    return [self filter:self.classProperties forName:name];
}

- (DYYYFLEXIvar *)ivarNamed:(NSString *)name {
    return [self filter:self.ivars forName:name];
}

- (DYYYFLEXProtocol *)protocolNamed:(NSString *)name {
    return [self filter:self.protocols forName:name];
}

@end
